import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Trial extends Task {
    int N, M, K;
    // int [][]data;
    ArrayList<ArrayList<Integer>> data;
    int firstIdx;

    public static void main(final String[] args) throws IOException, InterruptedException {
        Trial trial = new Trial();
        // trial.writeAnswer();
        trial.readProblemData();
        trial.formulateOracleQuestion();
        trial.askOracle();
        trial.decipherOracleAnswer();
    }
    @Override
    public void solve() throws IOException, InterruptedException {

    }
    @Override
    public void readProblemData() throws IOException {
        // BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Scanner scanner = new Scanner(System.in);

        this.N = scanner.nextInt();
        this.M = scanner.nextInt();
        this.K = scanner.nextInt();

        this.data = new ArrayList<>();
        // this.data = new int[M][N];

        int maxSize = 0;

        for (int i = 0; i < M; i++) {
            ArrayList<Integer> line = new ArrayList<>();

            int size = scanner.nextInt();
//            if (size > maxSize) {
//                maxSize = size;
//                this.firstIdx = i;
//            }

            for (int j = 0; j < size; j++) {
                // data[i][j] = scanner.nextInt();
                line.add(scanner.nextInt());
            }

            this.data.add(line);
        }

    }

    @Override
    public void formulateOracleQuestion() throws IOException {
        FileWriter file = new FileWriter("sat.cnf");

        int difNr = (this.M * (this.M - 1)) / 2 + this.M;

        file.write("p cnf " + (this.K * this.M) + " " + (this.K + difNr + this.N) + "\n");

        int [][] mat = new int[this.K][this.M];

        for (int i = 0; i < this.K; i++) {
            for (int j = 1; j <= this.M; j++) {
                file.write((this.M * i + j) + " ");
                mat[i][j - 1] = this.M * i + j;
            }
            file.write("0\n");
        }

        for (int i = 0; i < this.K; i++) {
            for (int j = 0; j < this.M - 1; j++) {
                for (int k = j + 1; k < this.M; k++) {
                    file.write(-mat[i][j] + " " + -mat[i][k] + " 0\n");
                }
            }
        }

        for (int nr = 1; nr <= this.N; nr++) {
            for (int subSetIdx = 0; subSetIdx < this.data.size(); subSetIdx++) {
                if (this.data.get(subSetIdx).contains(Integer.valueOf(nr))) {
                    for (int i = subSetIdx + 1; i <= this.M * this.K; i += this.M) {
                        file.write(i + " ");
                    }
                }
            }
            file.write("0\n");
        }

        file.close();
    }

    @Override
    public void decipherOracleAnswer() throws IOException {
        FileReader file = new FileReader("sat.sol");
        Scanner scanner = new Scanner(file);
        String res = scanner.nextLine();

        System.out.println(res);
        if (res.equals("False")) {
            return;
        }

        int size = scanner.nextInt();

        int  nrElem = 0;
        ArrayList<Integer> subSets = new ArrayList<>();

        for (int i = 0; i < size; i++) {
            int nr = scanner.nextInt();
            if (nr > 0) {
                nrElem++;
                if (nr % this.M == 0) {
                    subSets.add(this.M);
                } else {
                    subSets.add(nr % this.M);
                }
            }
        }

        System.out.println(nrElem);
        for (int i = 0; i < subSets.size(); i++) {
            System.out.print(subSets.get(i) + " ");
        }

//        char[] resp = new char[35000];
//        file.read(resp);

        // System.out.println(resp);

    }

    @Override
    public void writeAnswer() throws IOException {
        System.out.print("False");
    }
}


