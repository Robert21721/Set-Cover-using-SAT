import java.io.IOException;

public class Redemption extends Task {
    @Override
    public void solve() throws IOException, InterruptedException {

    }

    @Override
    public void readProblemData() throws IOException {

    }

    @Override
    public void formulateOracleQuestion() throws IOException {

    }

    @Override
    public void decipherOracleAnswer() throws IOException {

    }

    @Override
    public void writeAnswer() throws IOException {

    }
}
